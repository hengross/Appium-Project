package applications.vaadhorim.scenarios;

/**
 * Created by Amit on 07/12/2017.
 */

public class testRun {

    String user1Name = "";
    String user1Pass = " ";


}
